package com.example.finals.screens.login

class LoginPresenter(
    private var view: LoginContract.View?,
    private val model: LoginContract.Model
) : LoginContract.Presenter {

    override fun onLoginClicked(username: String, password: String) {
        if (username.isEmpty() || password.isEmpty()) {
            view?.showEmptyFieldsError()
            return
        }

        val user = model.login(username, password)
        if (user != null) {
            view?.showLoginSuccess()
            view?.navigateToProfile(user.fullName, user.username, user.email)
        } else {
            view?.showLoginError("Invalid username or password.")
        }
    }

    fun onRegisterClicked() {
        view?.navigateToRegister()
    }

    override fun saveUserData(fullName: String, username: String, password: String, email: String) {
        model.saveUser(fullName, username, password, email)
    }

    override fun onDestroy() {
        view = null
    }
}
