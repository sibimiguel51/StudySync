package com.example.finals.screens.login

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.finals.R
import com.example.finals.screens.dashboard.DashboardActivity
import com.example.finals.screens.register.RegisterActivity
import com.example.finals.utils.getTextString
import com.example.finals.utils.isEmpty
import com.example.finals.utils.showToast

class LoginActivity : Activity(), LoginContract.View {

    private lateinit var presenter: LoginContract.Presenter
    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etUsername = findViewById(R.id.usernameE)
        etPassword = findViewById(R.id.passwordE)
        btnLogin   = findViewById(R.id.btnID)
        tvRegister = findViewById(R.id.registerbtn)

        val model = LoginModel()
        presenter = LoginPresenter(this, model)

        val fullName = intent.getStringExtra("FULL_NAME") ?: ""
        val username = intent.getStringExtra("USERNAME") ?: ""
        val password = intent.getStringExtra("PASSWORD") ?: ""
        val email    = intent.getStringExtra("EMAIL") ?: ""

        if (username.isNotEmpty()) {
            presenter.saveUserData(fullName, username, password, email)
            etUsername.setText(username)
            showToast("Registration successful! Please login.")
        }

        tvRegister.setOnClickListener {
            (presenter as LoginPresenter).onRegisterClicked()
        }

        btnLogin.setOnClickListener {
            presenter.onLoginClicked(
                etUsername.getTextString(),
                etPassword.getTextString()
            )
        }
    }

    override fun showLoginSuccess() {
        showToast("Login successful!")
    }

    override fun showLoginError(message: String) {
        showToast(message)
    }

    override fun showEmptyFieldsError() {
        showToast("Please fill all fields")
        if (etUsername.isEmpty()) etUsername.setError("Username required")
        if (etPassword.isEmpty()) etPassword.setError("Password required")
    }


    override fun navigateToRegister() {
        val intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.onDestroy()
    }
    override fun navigateToProfile(fullName: String, username: String, email: String) {
        val intent = Intent(this, DashboardActivity::class.java)
        intent.putExtra("FULL_NAME", fullName)
        intent.putExtra("USERNAME", username)
        intent.putExtra("EMAIL", email)
        startActivity(intent)
        finish()
    }
}