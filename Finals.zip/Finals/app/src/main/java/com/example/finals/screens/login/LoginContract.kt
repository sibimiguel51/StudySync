package com.example.finals.screens.login

import com.example.finals.data.UserInfo

interface LoginContract {

    interface View {
        fun showLoginSuccess()
        fun showLoginError(message: String)
        fun showEmptyFieldsError()
        fun navigateToProfile(fullName: String, username: String, email: String)
        fun navigateToRegister()
    }

    interface Presenter {
        fun onLoginClicked(username: String, password: String)
        fun saveUserData(fullName: String, username: String, password: String, email: String)
        fun onDestroy()
    }

    interface Model {
        fun saveUser(fullName: String, username: String, password: String, email: String)
        fun login(username: String, password: String): UserInfo?
    }
}