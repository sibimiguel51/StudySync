package com.example.finals.data

data class UserInfo(
    val fullName: String,
    val username: String,
    val password: String,
    val email: String
)
