package com.example.finals.app

import android.app.Application

class CustomApp : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}