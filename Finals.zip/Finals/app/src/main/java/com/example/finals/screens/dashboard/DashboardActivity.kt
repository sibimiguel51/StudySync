package com.example.finals.screens.dashboard

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.finals.R
import com.example.finals.data.Task
import com.example.finals.screens.profile.ProfileActivity
import com.example.finals.utils.getTextString
import com.example.finals.utils.isEmpty
import com.example.finals.utils.showToast

class DashboardActivity : Activity() {

    private lateinit var rvTasks: RecyclerView
    private lateinit var etTaskTitle: EditText
    private lateinit var etTaskDesc: EditText
    private lateinit var btnAddTask: Button
    private lateinit var btnDeleteTask: Button
    private lateinit var btnProfile: Button
    private lateinit var tvUsername: TextView

    private lateinit var taskList: ArrayList<Task>
    private lateinit var adapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dasboard)

        rvTasks       = findViewById(R.id.rvTasks)
        etTaskTitle   = findViewById(R.id.etTaskTitle)
        etTaskDesc    = findViewById(R.id.etTaskDesc)
        btnAddTask    = findViewById(R.id.btnAddTask)
        btnDeleteTask = findViewById(R.id.btnDeleteTask)
        btnProfile    = findViewById(R.id.profileID)
        tvUsername    = findViewById(R.id.tvUsername)

        val fullName = intent.getStringExtra("FULL_NAME") ?: ""
        val username = intent.getStringExtra("USERNAME") ?: ""
        val email    = intent.getStringExtra("EMAIL") ?: ""

        tvUsername.text = "Welcome, $username!"

        taskList = ArrayList()
        adapter  = TaskAdapter(taskList) { position ->
            showToast("Selected: ${taskList[position].title}")
        }

        rvTasks.layoutManager = LinearLayoutManager(this)
        rvTasks.adapter       = adapter

        btnAddTask.setOnClickListener {
            val title = etTaskTitle.getTextString()
            val desc  = etTaskDesc.getTextString()

            if (etTaskTitle.isEmpty() || etTaskDesc.isEmpty()) {
                showToast("Please fill all fields")
                return@setOnClickListener
            }

            taskList.add(Task(title, desc))
            adapter.notifyDataSetChanged()
            etTaskTitle.setText("")
            etTaskDesc.setText("")
            showToast("Task added!")
        }

        btnDeleteTask.setOnClickListener {
            val position = adapter.getSelectedPosition()

            if (position == -1) {
                showToast("Please select a task first")
                return@setOnClickListener
            }

            AlertDialog.Builder(this)
                .setTitle("Remove Task")
                .setMessage("Do you want to remove this task?")
                .setPositiveButton("Yes") { _, _ ->
                    taskList.removeAt(position)
                    adapter.clearSelection()
                    adapter.notifyDataSetChanged()
                    showToast("Task removed!")
                }
                .setNegativeButton("No", null)
                .show()
        }

        btnProfile.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("FULL_NAME", fullName)
            intent.putExtra("USERNAME", username)
            intent.putExtra("EMAIL", email)
            startActivity(intent)
        }
    }
}