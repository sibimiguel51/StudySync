package com.example.finals.screens.login

import com.example.finals.data.UserInfo

class LoginModel : LoginContract.Model {

    private val users = mutableListOf<UserInfo>()

    override fun saveUser(fullName: String, username: String, password: String, email: String) {
        users.add(UserInfo(fullName, username, password, email))
    }

    override fun login(username: String, password: String): UserInfo? {
        return users.find { it.username == username && it.password == password }
    }
}