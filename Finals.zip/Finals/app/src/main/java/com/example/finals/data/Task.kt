package com.example.finals.data

data class Task(
    val title: String,
    val description: String
)