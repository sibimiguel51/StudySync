package com.example.finals.screens.register

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.finals.R
import com.example.finals.screens.login.LoginActivity
import com.example.finals.utils.getTextString
import com.example.finals.utils.isEmpty
import com.example.finals.utils.showToast

class RegisterActivity : Activity() {

    private lateinit var etFullName: EditText
    private lateinit var etUsername: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnRegister: Button
    private lateinit var tvLoginHere: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        etFullName        = findViewById(R.id.enterFullName)
        etUsername        = findViewById(R.id.enterUsername)
        etEmail           = findViewById(R.id.enterEmail)
        etPassword        = findViewById(R.id.enterPassword)
        etConfirmPassword = findViewById(R.id.enterConfirmPassword)
        btnRegister       = findViewById(R.id.registerButton)
        tvLoginHere       = findViewById(R.id.loginHere)

        btnRegister.setOnClickListener {
            val fullName        = etFullName.getTextString()
            val username        = etUsername.getTextString()
            val email           = etEmail.getTextString()
            val password        = etPassword.getTextString()
            val confirmPassword = etConfirmPassword.getTextString()

            // Empty field checks
            if (etFullName.isEmpty() || etUsername.isEmpty() ||
                etEmail.isEmpty() || etPassword.isEmpty() || etConfirmPassword.isEmpty()) {
                showToast("Please fill all fields")
                if (etFullName.isEmpty()) etFullName.setError("Full name required")
                if (etUsername.isEmpty()) etUsername.setError("Username required")
                if (etEmail.isEmpty()) etEmail.setError("Email required")
                if (etPassword.isEmpty()) etPassword.setError("Password required")
                if (etConfirmPassword.isEmpty()) etConfirmPassword.setError("Please confirm your password")
                return@setOnClickListener
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmail.setError("Enter a valid email (e.g. user@email.com)")
                etEmail.requestFocus()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                etConfirmPassword.setError("Passwords do not match")
                etConfirmPassword.requestFocus()
                showToast("Passwords do not match")
                return@setOnClickListener
            }

            showToast("Registration successful!")
            val intent = Intent(this, LoginActivity::class.java)
            intent.putExtra("FULL_NAME", fullName)
            intent.putExtra("USERNAME", username)
            intent.putExtra("PASSWORD", password)
            intent.putExtra("EMAIL", email)
            startActivity(intent)
            finish()
        }

        tvLoginHere.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}