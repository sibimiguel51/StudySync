package com.example.finals.screens.profile

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.finals.R
import com.example.finals.screens.dashboard.DashboardActivity
import com.example.finals.screens.login.LoginActivity
import com.example.finals.utils.showToast

class ProfileActivity : Activity() {

    private lateinit var tvFullName: TextView
    private lateinit var tvUsername: TextView
    private lateinit var tvEmail: TextView
    private lateinit var btnLogout: Button
    private lateinit var btnBack: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        tvFullName = findViewById(R.id.tvFullName)
        tvUsername = findViewById(R.id.tvUsername)
        tvEmail    = findViewById(R.id.tvEmail)
        btnLogout  = findViewById(R.id.btnLogout)
        btnBack    = findViewById(R.id.btnBack)

        val fullName = intent.getStringExtra("FULL_NAME") ?: ""
        val username = intent.getStringExtra("USERNAME") ?: ""
        val email    = intent.getStringExtra("EMAIL") ?: ""

        tvFullName.text = fullName
        tvUsername.text = username
        tvEmail.text    = email

        btnBack.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            finish()
        }

        btnLogout.setOnClickListener {
            showToast("Logged out.")
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}