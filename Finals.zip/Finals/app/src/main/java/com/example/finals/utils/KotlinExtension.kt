package com.example.finals.utils

import android.content.Context
import android.widget.EditText
import android.widget.Toast

fun Context.showToast(message: String) {
    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

fun EditText.getTextString(): String = text.toString().trim()

fun EditText.isEmpty(): Boolean = text.toString().trim().isEmpty()
